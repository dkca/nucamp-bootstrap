// You do not have to alter any of the code in this section for this challenge.

function changeColor() {
  const color = document.getElementById("colors").value;
  document.body.style.backgroundColor = color;
}